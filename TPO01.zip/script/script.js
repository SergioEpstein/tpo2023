var nombre = "Juan";
var apellido = "Lopez";
var edad = 42;
console.log(nombre );
console.log(apellido);
console.log(edad);
